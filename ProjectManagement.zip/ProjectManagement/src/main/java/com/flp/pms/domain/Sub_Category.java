package com.flp.pms.domain;

public class Sub_Category 
{
	private int sub_Category_Id;
	private String sub_Category_Name;
	private Category category_Id;
	
	public Sub_Category() {}

	public Sub_Category(int sub_Category_Id, String sub_Category_Name, Category category_Id) {
		super();
		this.sub_Category_Id = sub_Category_Id;
		this.sub_Category_Name = sub_Category_Name;
		this.category_Id = category_Id;
	}

	public int getSub_Category_Id() {
		return sub_Category_Id;
	}

	public void setSub_Category_Id(int sub_Category_Id) {
		this.sub_Category_Id = sub_Category_Id;
	}

	public String getSub_Category_Name() {
		return sub_Category_Name;
	}

	public void setSub_Category_Name(String sub_Category_Name) {
		this.sub_Category_Name = sub_Category_Name;
	}

	public Category getCategory_Id() {
		return category_Id;
	}

	public void setCategory_Id(Category category_Id) {
		this.category_Id = category_Id;
	}

	@Override
	public String toString() {
		return "Sub_Category [sub_Category_Id=" + sub_Category_Id + ", sub_Category_Name=" + sub_Category_Name
				+ ", category_Id=" + category_Id + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((category_Id == null) ? 0 : category_Id.hashCode());
		result = prime * result + sub_Category_Id;
		result = prime * result + ((sub_Category_Name == null) ? 0 : sub_Category_Name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Sub_Category other = (Sub_Category) obj;
		if (category_Id == null) {
			if (other.category_Id != null)
				return false;
		} else if (!category_Id.equals(other.category_Id))
			return false;
		if (sub_Category_Id != other.sub_Category_Id)
			return false;
		if (sub_Category_Name == null) {
			if (other.sub_Category_Name != null)
				return false;
		} else if (!sub_Category_Name.equals(other.sub_Category_Name))
			return false;
		return true;
	} 
	
	
	
	
	
}
