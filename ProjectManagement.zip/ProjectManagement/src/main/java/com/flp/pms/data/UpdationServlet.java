package com.flp.pms.data;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.dao.ProductDaoImplforMap;

public class UpdationServlet extends  HttpServlet
{
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		
		ProductDaoImplforMap db = new ProductDaoImplforMap();
		
		ServletContext context=getServletContext();  
		String id=(String)context.getAttribute("productid");  
		
		String option = request.getParameter("option");
		
		if(option.equals("Name"))
		{
			response.sendRedirect("pages/updatename.html");
			  	   
		}
		
		else if(option.equals("Price"))
		{
			response.sendRedirect("pages/updateprice.html");
			  	   
		}
		
		else if(option.equals("Expiry Date"))
		{
			response.sendRedirect("pages/updateexdate.html");
		}
		
		else if(option.equals("Ratings"))
		{
			response.sendRedirect("pages/updaterating.html");
			  	   
		}
		
		else if(option.equals("Category"))
		{
			response.sendRedirect("pages/updatecategory.html");
			  	   
		}
}
}