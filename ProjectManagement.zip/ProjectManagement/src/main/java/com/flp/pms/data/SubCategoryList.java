package com.flp.pms.data;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImplforMap;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.Sub_Category;
import com.google.gson.Gson;

public class SubCategoryList extends HttpServlet
{
private static final long serialVersionUID = 1L;

protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	response.setContentType("application/json");
	
	PrintWriter out=response.getWriter();
	IProductDao iProductDao=new ProductDaoImplforMap();
	
		List<Sub_Category> product=iProductDao.getAllSubCategory();
		
			Gson myJson=new Gson();
		
		String productjson=myJson.toJson(product);		
		    out.println(productjson);
}
}
